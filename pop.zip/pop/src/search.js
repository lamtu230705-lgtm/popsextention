function execute(key, page) {
    if (!page) page = "1";
    
    // Sử dụng API tìm kiếm của POPS (hoặc giả lập qua trang search)
    var searchUrl = "https://pops.vn/search?q=" + encodeURIComponent(key) + "&type=story";
    var doc = Http.get(searchUrl).html();
    var bookList = [];

    if (doc) {
        var scriptTag = doc.select("script#__NEXT_DATA__").first();
        if (scriptTag) {
            var data = JSON.parse(scriptTag.html());
            var results = data.props.pageProps.searchResults || [];

            results.forEach(item => {
                bookList.push({
                    name: item.title,
                    link: "https://pops.vn/story/" + item.slug + "-" + item.id,
                    cover: item.thumbnail,
                    description: "Tác giả: " + (item.author || "POPS Việt Nam"),
                    host: "https://pops.vn"
                });
            });
            return Response.success(bookList);
        }
    }
    return null;
}