function execute() {
    // POPS phân chia mục truyện chữ theo các sub-url hoặc API, đây là các đầu mục chính
    return Response.success([
        { title: "Truyện Chữ Mới Nhất", input: "https://pops.vn/story?sort=new", script: "gen.js" },
        { title: "Truyện Xem Nhiều", input: "https://pops.vn/story?sort=top", script: "gen.js" }
    ]);
}