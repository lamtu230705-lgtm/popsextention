function execute(url, page) {
    if (!page) page = "1";
    
    // Tải HTML của trang danh mục
    var doc = Http.get(url + "&page=" + page).html();
    var bookList = [];

    if (doc) {
        // Bóc tách JSON từ thẻ __NEXT_DATA__ của Next.js
        var scriptTag = doc.select("script#__NEXT_DATA__").first();
        if (scriptTag) {
            var data = JSON.parse(scriptTag.html());
            // Duyệt qua danh sách các item truyện trong JSON tương ứng của POPS
            var items = data.props.pageProps.items || []; 
            
            items.forEach(item => {
                bookList.push({
                    name: item.title,
                    link: "https://pops.vn/story/" + item.slug + "-" + item.id,
                    cover: item.thumbnail,
                    description: item.brief || "Đang cập nhật...",
                    host: "https://pops.vn"
                });
            });
            
            // Tính toán trang tiếp theo dựa trên cấu trúc phân trang của POPS
            var hasNext = data.props.pageProps.hasNextPage;
            var next = hasNext ? (parseInt(page) + 1).toString() : null;
            
            return Response.success(bookList, next);
        }
    }
    return null;
}