function execute(url) {
    var doc = Http.get(url).html();
    
    if (doc) {
        var scriptTag = doc.select("script#__NEXT_DATA__").first();
        if (scriptTag) {
            var data = JSON.parse(scriptTag.html());
            // Lấy nội dung text dạng mảng hoặc chuỗi thô từ JSON của POPS
            var contentArray = data.props.pageProps.chapterDetail.content || [];
            
            // Nối các đoạn văn lại với nhau bằng thẻ <br> để xuống dòng trên app vBook
            var output_text = contentArray.join("<br><br>");
            
            return Response.success(output_text);
        }
    }   
    return null;
}