function execute(url) {
    var doc = Http.get(url).html();
    var list_chapter = [];

    if (doc) {
        var scriptTag = doc.select("script#__NEXT_DATA__").first();
        if (scriptTag) {
            var data = JSON.parse(scriptTag.html());
            // Lấy danh sách chương từ dữ liệu đã nạp sẵn trên trang detail
            var chapters = data.props.pageProps.storyDetail.chapters || [];

            chapters.forEach(chap => {
                list_chapter.push({
                    name: chap.title || "Chương " + chap.index,
                    url: "https://pops.vn/story/chapter/" + chap.id,
                    host: "https://pops.vn"
                });
            });
            return Response.success(list_chapter);
        }
    }
    return null;
}