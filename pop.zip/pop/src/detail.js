function execute(url) {
    var doc = Http.get(url).html();
    
    if (doc) {
        var scriptTag = doc.select("script#__NEXT_DATA__").first();
        if (scriptTag) {
            var data = JSON.parse(scriptTag.html());
            var detailData = data.props.pageProps.storyDetail; // Node chứa thông tin chi tiết truyện

            return Response.success({
                name: detailData.title,
                cover: detailData.thumbnail,
                host: "https://pops.vn",
                author: detailData.author || "POPS",
                description: detailData.description,
                detail: "Trạng thái: " + (detailData.status || "Đang tiến hành") + "<br>Thể loại: " + detailData.genre
            });
        }
    }
    return null;
}